#!/usr/bin/env sh
set -e
set -x

Version="$(cat Версія)"
ReleaseFiles=$(cat ФайлиВипуску)

mkdir -p "releases/$Version"

sh external/scripts/prepare.sh linux-x86_64
cd build/linux-x86_64
sh build.sh
sh package.sh
cd -

cp "build/linux-x86_64/package/КД-$Version-linux-x86_64.tar.gz" "releases/$Version"
cp "build/linux-x86_64/package/КД-$Version-linux-x86_64-prepared.tar.gz" "releases/$Version"

mkdir -p "releases/$Version/КД-$Version"

while IFS='' read -r ReleaseFile
do
  cp -r "$ReleaseFile" "releases/$Version/КД-$Version"
done <<ReleaseFiles_HEREDOC_INPUT
$ReleaseFiles
ReleaseFiles_HEREDOC_INPUT

cd "releases/$Version"
tar -czvf "КД-$Version.tar.gz" "КД-$Version"
cd -

rm -rf "releases/$Version/КД-$Version"