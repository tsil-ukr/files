#!/usr/bin/env sh
set -e

KDVersion="$(cat Версія)"

Mode="$1"
if [ -z "$Mode" ]
then
  Mode="release"
fi

export CC="clang -target x86_64-pc-linux-gnu"
export CXX="clang++ -target x86_64-pc-linux-gnu"
export AR="llvm-ar"
export RANLIB="llvm-ranlib"
CC_OPTIONS="-DKD_VERSION=\"$KDVersion\""

appendCcOption() {
  if [ -z "$CC_OPTIONS" ]
  then
    CC_OPTIONS="$1"
  else
    CC_OPTIONS="$CC_OPTIONS $1"
  fi
}

case "$Mode" in
  "release"*)
    appendCcOption "-static"
    appendCcOption "-O3"
    appendCcOption "-g0"
    appendCcOption "-flto"
    appendCcOption "-ffast-math"
    appendCcOption "-fvisibility=hidden"
  ;;
  "debug-asan"*)
    appendCcOption "-g -fsanitize=address,undefined,leak"
  ;;
  "debug"*)
    appendCcOption "-g"
  ;;
esac

appendCcOption "-lm"

SourceFiles="$(cat SourceFiles)"
mkdir -p "out"
Command="$CC $CC_OPTIONS -o out/кд $SourceFiles"
echo "$Command"
$Command