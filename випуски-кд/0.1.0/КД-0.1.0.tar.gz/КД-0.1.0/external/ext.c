#include <math.h>
#include <memory.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define п8 uint8_t
#define п16 uint16_t
#define п32 uint32_t
#define п64 uint64_t
#define ц8 int8_t
#define ц16 int16_t
#define ц32 int32_t
#define ц64 int64_t
#define д32 float
#define д64 double
#define логічне uint8_t
#define позитивне п64
#define ціле ц64
#define дійсне д64
#define ніщо void
#define невідома_адреса void*
#define невідома_памʼять void*
#define памʼять_п8 п8*
#define адреса_памʼять_п8 п8**
#define памʼять_памʼять_п8 п8**
#define адреса_позитивне позитивне*
typedef struct т8 {
  позитивне розмір;
  памʼять_п8 дані;
} т8;
typedef struct ю8 {
  позитивне розмір;
  памʼять_п8 дані;
} ю8;
#define памʼять_т8 т8*
#define памʼять_ю8 ю8*

typedef struct ЗначенняФайлу {
  позитивне розмір;
  памʼять_п8 дані;
} ЗначенняФайлу;

char* ю8_as_char(ю8 value) {
  char* copy = (char*)malloc(value.розмір + 1);
  memcpy(copy, value.дані, value.розмір);
  copy[value.розмір] = 0;
  return copy;
}

extern памʼять_п8 кд_система_виділити_сиру_памʼять(позитивне розмір);
extern памʼять_п8 кд_система_перевиділити_сиру_памʼять(памʼять_п8 значення,
                                                       позитивне новий_розмір);
extern ніщо кд_система_звільнити_сиру_памʼять(памʼять_п8 значення);
extern ніщо кд_система_вивести_ю8(ю8 значення);
extern логічне кд_система_прочитати_файл(ю8 шлях, ЗначенняФайлу* вихід);
extern логічне кд_система_записати_у_файл(ю8 шлях, ЗначенняФайлу значення);

extern памʼять_п8 кд_система_виділити_сиру_памʼять(позитивне розмір) {
  return (памʼять_п8)malloc(розмір);
}

extern памʼять_п8 кд_система_перевиділити_сиру_памʼять(памʼять_п8 значення,
                                                       позитивне новий_розмір) {
  return (памʼять_п8)realloc(значення, новий_розмір);
}

extern ніщо кд_система_звільнити_сиру_памʼять(памʼять_п8 значення) {
  free(значення);
}

extern ніщо кд_система_вивести_ю8(ю8 значення) {
  for (позитивне i = 0; i < значення.розмір; ++i) {
    putchar(значення.дані[i]);
  }
}

extern логічне кд_система_прочитати_файл(ю8 шлях, ЗначенняФайлу* вихід) {
  const char* path = ю8_as_char(шлях);
  FILE* f = fopen(path, "rb");
  free((void*)path);
  if (f == NULL) {
    return false;
  }
  fseek(f, 0, SEEK_END);
  long fsize = ftell(f);
  fseek(f, 0, SEEK_SET);
  char* buffer = malloc(fsize);
  fread(buffer, fsize, 1, f);
  fclose(f);
  вихід->розмір = fsize;
  вихід->дані = (памʼять_п8)buffer;
  return true;
}

extern логічне кд_система_записати_у_файл(ю8 шлях, ЗначенняФайлу значення) {
  const char* path = ю8_as_char(шлях);
  FILE* f = fopen(path, "wb");
  free((void*)path);
  if (f == NULL) {
    return false;
  }
  fwrite(значення.дані, sizeof(п8), значення.розмір, f);
  fclose(f);
  return true;
}

extern ц32 запустити_кд_аргументи_ю8(позитивне кількість_аргументів,
                                     памʼять_ю8 аргументи);

int main(int argc, char** argv) {
  ю8 аргументи[argc];
  for (int i = 0; i < argc; ++i) {
    аргументи[i].розмір = strlen(argv[i]);
    аргументи[i].дані = (памʼять_п8)argv[i];
  }
  return запустити_кд_аргументи_ю8(argc, аргументи);
}