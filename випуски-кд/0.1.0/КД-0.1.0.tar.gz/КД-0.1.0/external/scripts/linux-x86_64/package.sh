#!/usr/bin/env sh
set -e
set -x

KD_VERSION="$(cat Версія)"

mkdir -p "package/КД-$KD_VERSION-linux-x86_64/bin"
mkdir -p "package/КД-$KD_VERSION-linux-x86_64-prepared"

cp "out/кд" "package/КД-$KD_VERSION-linux-x86_64/bin/кд"
cd "package"
tar -czvf "КД-$KD_VERSION-linux-x86_64.tar.gz" "КД-$KD_VERSION-linux-x86_64"
cd -

cp -a source build.sh package.sh SourceFiles Версія "package/КД-$KD_VERSION-linux-x86_64-prepared"
cd "package"
tar -czvf "КД-$KD_VERSION-linux-x86_64-prepared.tar.gz" "КД-$KD_VERSION-linux-x86_64-prepared"
cd -