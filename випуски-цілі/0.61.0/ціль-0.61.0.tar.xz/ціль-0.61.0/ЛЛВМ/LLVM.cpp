#include <iostream>
#include "llvm/Bitcode/BitcodeWriter.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"
#include "llvm/MC/TargetRegistry.h"
#include "llvm/Support/ManagedStatic.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Target/TargetMachine.h"
#include "llvm/Target/TargetOptions.h"
#include "llvm/TargetParser/Host.h"

static std::unique_ptr<llvm::LLVMContext> llvmContext;

typedef llvm::Module Модуль;
typedef llvm::Function Функція;
typedef llvm::Value Значення;
typedef llvm::Type Тип;
typedef llvm::BasicBlock БазовийБлок;
typedef llvm::BranchInst ІнструкціяРозгалуження;

extern "C" {
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define п8 uint8_t
#define п16 uint16_t
#define п32 uint32_t
#define п64 uint64_t
#define ц8 int8_t
#define ц16 int16_t
#define ц32 int32_t
#define ц64 int64_t
#define р32 float
#define р64 double
#define логічне uint8_t
#define природне п64
#define ціле ц64
#define дробове р64
#define ніщо void
#define адреса_ніщо void*
#define памʼять <ніщо> void*
typedef struct кд {
  природне розмір;
  п8* дані;
} кд;
typedef struct ю8 {
  природне розмір;
  п8* дані;
} ю8;
#define памʼять_кд кд*
#define памʼять_ю8 ю8*

#define ВИДИМІСТЬ_ВНУТРІШНЯ 1
#define ВИДИМІСТЬ_ЗОВНІШНЯ 3

#define ПЛАТФОРМА_ЛІНУКС_ІКС86_64 10
#define ПЛАТФОРМА_ЛІНУКС_ААРЧ64 11
#define ПЛАТФОРМА_МАКОС_ІКС86_64 20
#define ПЛАТФОРМА_МАКОС_ААРЧ64 21
#define ПЛАТФОРМА_ВІНДОВС_ІКС86_64 30
#define ПЛАТФОРМА_ВІНДОВС_ААРЧ64 31
#define ПЛАТФОРМА_ВАСМ32 40
#define ПЛАТФОРМА_ВАСМ64 41

void __ЛЛВМ__ініціалізувати() {
  llvm::InitializeAllTargetInfos();
  llvm::InitializeAllTargets();
  llvm::InitializeAllTargetMCs();
  llvm::InitializeAllAsmParsers();
  llvm::InitializeAllAsmPrinters();

  llvmContext = std::make_unique<llvm::LLVMContext>();
}

void __ЛЛВМ__деініціалізувати() {
  // llvmContext.reset();

  // llvm::llvm_shutdown();
}

Тип* __ЛЛВМ__тип_войд() {
  return llvm::Type::getVoidTy(*llvmContext);
}

Тип* __ЛЛВМ__тип_пойнтер() {
  return llvm::PointerType::get(*llvmContext, 0);
}

Тип* __ЛЛВМ__тип_і1() {
  return llvm::Type::getInt1Ty(*llvmContext);
}

Тип* __ЛЛВМ__тип_і8() {
  return llvm::Type::getInt8Ty(*llvmContext);
}

Тип* __ЛЛВМ__тип_і16() {
  return llvm::Type::getInt16Ty(*llvmContext);
}

Тип* __ЛЛВМ__тип_і32() {
  return llvm::Type::getInt32Ty(*llvmContext);
}

Тип* __ЛЛВМ__тип_і64() {
  return llvm::Type::getInt64Ty(*llvmContext);
}

Тип* __ЛЛВМ__тип_флоат() {
  return llvm::Type::getFloatTy(*llvmContext);
}

Тип* __ЛЛВМ__тип_даубл() {
  return llvm::Type::getDoubleTy(*llvmContext);
}

Тип* __ЛЛВМ__тип_функція(природне кількість_параметрів,
                         Тип** параметри,
                         Тип* тип_результату) {
  return llvm::FunctionType::get(
      тип_результату == nullptr ? llvm::Type::getVoidTy(*llvmContext)
                                : тип_результату,
      llvm::ArrayRef<llvm::Type*>(параметри, кількість_параметрів), false);
}

Тип* __ЛЛВМ__тип_аррай(Тип* тип_елемента, природне розмір) {
  return llvm::ArrayType::get(тип_елемента, розмір);
}

Тип* __ЛЛВМ__тип(ю8* назва,
                 природне кількість_параметрів,
                 Тип** параметри,
                 природне пакована) {
  std::string name((char*)назва->дані, назва->розмір);

  std::vector<llvm::Type*> llvmFields(кількість_параметрів);
  for (int i = 0; i < кількість_параметрів; i++) {
    llvmFields[i] = параметри[i];
  }

  return llvm::StructType::create(*llvmContext, llvmFields, name,
                                  static_cast<bool>(пакована));
}

Значення* __ЛЛВМ__нулл() {
  return llvm::ConstantPointerNull::get(
      llvm::PointerType::get(llvm::Type::getVoidTy(*llvmContext), 0));
}

Значення* __ЛЛВМ__і1(п8 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(1, значення ? 1 : 0));
}

Значення* __ЛЛВМ__і8(п8 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(8, значення));
}

Значення* __ЛЛВМ__і16(п16 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(16, значення));
}

Значення* __ЛЛВМ__і32(п32 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(32, значення));
}

Значення* __ЛЛВМ__і64(п64 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(64, значення));
}

Значення* __ЛЛВМ__і8ц(ц8 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(8, значення, true));
}

Значення* __ЛЛВМ__і16ц(ц16 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(16, значення, true));
}

Значення* __ЛЛВМ__і32ц(ц32 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(32, значення, true));
}

Значення* __ЛЛВМ__і64ц(ц64 значення) {
  return llvm::ConstantInt::get(*llvmContext, llvm::APInt(64, значення, true));
}

Значення* __ЛЛВМ__флоат(р32 значення) {
  return llvm::ConstantFP::get(*llvmContext, llvm::APFloat(значення));
}

Значення* __ЛЛВМ__даубл(р64 значення) {
  return llvm::ConstantFP::get(*llvmContext, llvm::APFloat(значення));
}

Модуль* __ЛЛВМ__створити_модуль(ю8* назва, природне платформа) {
  std::string name((char*)назва->дані, назва->розмір);

  auto llvmModule = new llvm::Module(name, *llvmContext);

  std::string targetTriple;

  if (платформа) {
    if (платформа == ПЛАТФОРМА_ЛІНУКС_ІКС86_64) {
      targetTriple = "x86_64-pc-linux-gnu";
    } else if (платформа == ПЛАТФОРМА_ЛІНУКС_ААРЧ64) {
      targetTriple = "aarch64-pc-linux-gnu";
    } else if (платформа == ПЛАТФОРМА_МАКОС_ІКС86_64) {
      targetTriple = "x86_64-apple-darwin";
    } else if (платформа == ПЛАТФОРМА_МАКОС_ААРЧ64) {
      targetTriple = "aarch64-apple-darwin";
    } else if (платформа == ПЛАТФОРМА_ВІНДОВС_ІКС86_64) {
      targetTriple = "x86_64-pc-windows-gnu";
    } else if (платформа == ПЛАТФОРМА_ВІНДОВС_ААРЧ64) {
      targetTriple = "aarch64-pc-windows-gnu";
    } else if (платформа == ПЛАТФОРМА_ВАСМ32) {
      targetTriple = "wasm32-unknown-unknown";
    } else if (платформа == ПЛАТФОРМА_ВАСМ64) {
      targetTriple = "wasm64-unknown-unknown";
    } else {
      return nullptr;
    }
  } else {
    targetTriple = llvm::sys::getDefaultTargetTriple();
  }

  llvmModule->setTargetTriple(targetTriple);

  std::string Error;
  auto Target = llvm::TargetRegistry::lookupTarget(targetTriple, Error);
  if (!Error.empty()) {
    std::cout << Error << std::endl;
    return nullptr;
  }

  auto CPU = "generic";
  auto Features = "";

  llvm::TargetOptions opt;

  auto llvmTargetMachine = Target->createTargetMachine(
      targetTriple, CPU, Features, opt, llvm::Reloc::PIC_);

  llvmModule->setDataLayout(llvmTargetMachine->createDataLayout());

  return llvmModule;
}

void __ЛЛВМ__знищити_модуль(Модуль* модуль) {
  // delete модуль;
}

Функція* __ЛЛВМ__створити_функцію(Модуль* модуль,
                                  природне видимість,
                                  ю8* назва,
                                  природне кількість_параметрів,
                                  Тип** параметри,
                                  Тип* тип_результату) {
  llvm::Function::LinkageTypes linkageType;
  if (видимість == ВИДИМІСТЬ_ЗОВНІШНЯ) {
    linkageType = llvm::Function::ExternalLinkage;
  } else {
    linkageType = llvm::Function::PrivateLinkage;
  }

  std::string name((char*)назва->дані, назва->розмір);

  std::vector<llvm::Type*> llvmParams(кількість_параметрів);
  for (int i = 0; i < кількість_параметрів; i++) {
    llvmParams[i] = параметри[i];
  }

  auto functionType = llvm::FunctionType::get(
      тип_результату == nullptr ? llvm::Type::getVoidTy(*llvmContext)
                                : тип_результату,
      llvmParams, false);

  return llvm::Function::Create(functionType, linkageType, name, модуль);
}

Значення* __ЛЛВМ__отримати_аргумент_функції(Функція* функція,
                                            природне позиція) {
  return функція->getArg(позиція);
}

Значення* __ЛЛВМ__створити_базовий_блок(Функція* функція, ю8* назва) {
  return llvm::BasicBlock::Create(*llvmContext, "bb", функція);
}

Значення* __ЛЛВМ__інст_аллока(БазовийБлок* базовий_блок, Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateAlloca(тип, nullptr, "alloca");
}

Значення* __ЛЛВМ__інст_адд(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateAdd(ліво, право, "addtmp");
}

Значення* __ЛЛВМ__інст_фадд(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFAdd(ліво, право, "faddtmp");
}

Значення* __ЛЛВМ__інст_саб(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateSub(ліво, право, "subtmp");
}

Значення* __ЛЛВМ__інст_фсаб(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFSub(ліво, право, "fsubtmp");
}

Значення* __ЛЛВМ__інст_мул(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateMul(ліво, право, "multmp");
}

Значення* __ЛЛВМ__інст_фмул(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFMul(ліво, право, "fmultmp");
}

Значення* __ЛЛВМ__інст_сдів(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateSDiv(ліво, право, "sdivtmp");
}

Значення* __ЛЛВМ__інст_удів(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateUDiv(ліво, право, "udivtmp");
}

Значення* __ЛЛВМ__інст_фдів(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFDiv(ліво, право, "fdivtmp");
}

Значення* __ЛЛВМ__інст_срем(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateSRem(ліво, право, "sremtmp");
}

Значення* __ЛЛВМ__інст_урем(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateURem(ліво, право, "uremtmp");
}

Значення* __ЛЛВМ__інст_фрем(БазовийБлок* базовий_блок,
                            Значення* ліво,
                            Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFRem(ліво, право, "fremtmp");
}

Значення* __ЛЛВМ__інст_іцмпекʼю(БазовийБлок* базовий_блок,
                                Значення* ліво,
                                Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpEQ(ліво, право, "icmpetmp");
}

Значення* __ЛЛВМ__інст_фцмпекʼю(БазовийБлок* базовий_блок,
                                Значення* ліво,
                                Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpUEQ(ліво, право, "fcmpetmp");
}

Значення* __ЛЛВМ__інст_іцмпне(БазовийБлок* базовий_блок,
                              Значення* ліво,
                              Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpNE(ліво, право, "icmpnetmp");
}

Значення* __ЛЛВМ__інст_фцмпуне(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpUNE(ліво, право, "fcmpunetmp");
}

Значення* __ЛЛВМ__інст_іцмпугт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpUGT(ліво, право, "icmpugttmp");
}

Значення* __ЛЛВМ__інст_іцмпсгт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpSGT(ліво, право, "icmpsgttmp");
}

Значення* __ЛЛВМ__інст_фцмпугт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpUGT(ліво, право, "fcmpugttmp");
}

Значення* __ЛЛВМ__інст_іцмпулт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpULT(ліво, право, "icmpulttmp");
}

Значення* __ЛЛВМ__інст_іцмпслт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpSLT(ліво, право, "icmpslttmp");
}

Значення* __ЛЛВМ__інст_фцмпулт(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpULT(ліво, право, "fcmpulttmp");
}

Значення* __ЛЛВМ__інст_іцмпуге(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpUGE(ліво, право, "icmpugetmp");
}

Значення* __ЛЛВМ__інст_іцмпсге(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpSGE(ліво, право, "icmpsgetmp");
}

Значення* __ЛЛВМ__інст_фцмпуге(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpUGE(ліво, право, "fcmpugetmp");
}

Значення* __ЛЛВМ__інст_іцмпуле(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpULE(ліво, право, "icmpuletmp");
}

Значення* __ЛЛВМ__інст_іцмпсле(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateICmpSLE(ліво, право, "icmpsletmp");
}

Значення* __ЛЛВМ__інст_фцмпуле(БазовийБлок* базовий_блок,
                               Значення* ліво,
                               Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFCmpULE(ліво, право, "fcmpuletmp");
}

Значення* __ЛЛВМ__інст_шл(БазовийБлок* базовий_блок,
                          Значення* ліво,
                          Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateShl(ліво, право, "shltmp");
}

Значення* __ЛЛВМ__інст_ашр(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateAShr(ліво, право, "ashrtmp");
}

Значення* __ЛЛВМ__інст_лшр(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateLShr(ліво, право, "lshrtmp");
}

Значення* __ЛЛВМ__інст_анд(БазовийБлок* базовий_блок,
                           Значення* ліво,
                           Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateAnd(ліво, право, "andtmp");
}

Значення* __ЛЛВМ__інст_ор(БазовийБлок* базовий_блок,
                          Значення* ліво,
                          Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateOr(ліво, право, "ortmp");
}

Значення* __ЛЛВМ__інст_іксор(БазовийБлок* базовий_блок,
                             Значення* ліво,
                             Значення* право) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateXor(ліво, право, "xortmp");
}

Значення* __ЛЛВМ__інст_біткаст(БазовийБлок* базовий_блок,
                               Значення* значення,
                               Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateBitCast(значення, тип, "bitcasttmp");
}

Значення* __ЛЛВМ__інст_гетелементптр(БазовийБлок* базовий_блок,
                                     Тип* тип,
                                     Значення* значення,
                                     природне кількість_індексів,
                                     Значення** індекси) {
  llvm::IRBuilder<> builder(базовий_блок);

  std::vector<llvm::Value*> llvmIndices(кількість_індексів);
  for (int i = 0; i < кількість_індексів; i++) {
    llvmIndices[i] = індекси[i];
  }

  return builder.CreateGEP(тип, значення,
                           llvm::ArrayRef<llvm::Value*>(llvmIndices),
                           "getelementptrtmp");
}

Значення* __ЛЛВМ__екстракт_валуе(БазовийБлок* базовий_блок,
                                 Значення* значення,
                                 природне індекс) {
  llvm::IRBuilder<> builder(базовий_блок);

  return builder.CreateExtractValue(
      значення, {static_cast<unsigned int>(індекс)}, "extractvaluetmp");
}

Значення* __ЛЛВМ__інст_сторе(БазовийБлок* базовий_блок,
                             Значення* значення,
                             Значення* куди) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateStore(значення, куди);
}

Значення* __ЛЛВМ__інст_лоад(БазовийБлок* базовий_блок,
                            Тип* тип,
                            Значення* звідки) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateLoad(тип, звідки, "loadtmp");
}

Значення* __ЛЛВМ__інст_зекст(БазовийБлок* базовий_блок,
                             Значення* значення,
                             Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateZExt(значення, тип, "zexttmp");
}

Значення* __ЛЛВМ__інст_секст(БазовийБлок* базовий_блок,
                             Значення* значення,
                             Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateSExt(значення, тип, "sexttmp");
}

Значення* __ЛЛВМ__інст_трунк(БазовийБлок* базовий_блок,
                             Значення* значення,
                             Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateTrunc(значення, тип, "trunctmp");
}

Значення* __ЛЛВМ__інст_уітуфп(БазовийБлок* базовий_блок,
                              Значення* значення,
                              Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateUIToFP(значення, тип, "uitofptmp");
}

Значення* __ЛЛВМ__інст_сітуфп(БазовийБлок* базовий_блок,
                              Значення* значення,
                              Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateSIToFP(значення, тип, "sitofptmp");
}

Значення* __ЛЛВМ__інст_фпекст(БазовийБлок* базовий_блок,
                              Значення* значення,
                              Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFPExt(значення, тип, "fpexttmp");
}

Значення* __ЛЛВМ__інст_фптрунк(БазовийБлок* базовий_блок,
                               Значення* значення,
                               Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFPTrunc(значення, тип, "fptrunctmp");
}

Значення* __ЛЛВМ__інст_фптууі(БазовийБлок* базовий_блок,
                              Значення* значення,
                              Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFPToUI(значення, тип, "fptoutmp");
}

Значення* __ЛЛВМ__інст_фптусі(БазовийБлок* базовий_блок,
                              Значення* значення,
                              Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateFPToSI(значення, тип, "fptositmp");
}

Значення* __ЛЛВМ__інст_інттуптр(БазовийБлок* базовий_блок,
                                Значення* значення,
                                Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateIntToPtr(значення, тип, "inttoptrtmp");
}

Значення* __ЛЛВМ__інст_птртуінт(БазовийБлок* базовий_блок,
                                Значення* значення,
                                Тип* тип) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreatePtrToInt(значення, тип, "ptrtointtmp");
}

Значення* __ЛЛВМ__інст_рет(БазовийБлок* базовий_блок, Значення* значення) {
  llvm::IRBuilder<> builder(базовий_блок);
  if (значення == nullptr) {
    return builder.CreateRetVoid();
  }
  return builder.CreateRet(значення);
}

Значення* __ЛЛВМ__інст_калл(БазовийБлок* базовий_блок,
                            Тип* тип,
                            Значення* значення,
                            природне кількість_аргументів,
                            Значення** аргументи) {
  llvm::IRBuilder<> builder(базовий_блок);

  std::vector<llvm::Value*> llvmArguments(кількість_аргументів);
  for (int i = 0; i < кількість_аргументів; i++) {
    llvmArguments[i] = аргументи[i];
  }

  auto type = reinterpret_cast<llvm::FunctionType*>(тип);

  if (type->getReturnType()->isVoidTy()) {
    return builder.CreateCall(type, значення, llvmArguments);
  }

  return builder.CreateCall(type, значення, llvmArguments, "calltmp");
}

Значення* __ЛЛВМ__інст_бр(БазовийБлок* базовий_блок, БазовийБлок* куди) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateBr(куди);
}

Значення* __ЛЛВМ__інст_кондбр(БазовийБлок* базовий_блок,
                              Значення* умова,
                              БазовийБлок* якщо_істина,
                              БазовийБлок* якщо_хиба) {
  llvm::IRBuilder<> builder(базовий_блок);
  return builder.CreateCondBr(умова, якщо_істина, якщо_хиба);
}

Значення* __ЛЛВМ__створити_глобал_варіабле(Модуль* модуль,
                                           природне видимість,
                                           ю8* назва,
                                           Тип* тип) {
  llvm::GlobalValue::LinkageTypes linkageType;
  if (видимість == ВИДИМІСТЬ_ЗОВНІШНЯ) {
    linkageType = llvm::GlobalValue::ExternalLinkage;
  } else {
    linkageType = llvm::GlobalValue::PrivateLinkage;
  }

  std::string name((char*)назва->дані, назва->розмір);

  return new llvm::GlobalVariable(*модуль, тип, false, linkageType, nullptr,
                                  name);
}

Значення* __ЛЛВМ__створити_глобал_константу_даних(Модуль* модуль,
                                                  природне розмір,
                                                  п8* дані) {
  auto constantString = llvm::ConstantDataArray::getString(
      *llvmContext, std::string((char*)дані, розмір), false);

  return new llvm::GlobalVariable(
      *модуль,
      llvm::ArrayType::get(llvm::Type::getInt8Ty(*llvmContext), розмір), true,
      llvm::GlobalValue::LinkageTypes::PrivateLinkage, constantString);
}

Значення* __ЛЛВМ__констант_структ(Модуль* модуль,
                                  Тип* тип,
                                  природне кількість_аргументів,
                                  Значення** аргументи) {
  return llvm::ConstantStruct::get(
      (llvm::StructType*)тип,
      llvm::ArrayRef((llvm::Constant**)аргументи, кількість_аргументів));
}

Значення* __ЛЛВМ__констант_нулл_валуе(Модуль* модуль, Тип* тип) {
  return llvm::Constant::getNullValue(тип);
}

логічне __ЛЛВМ__перетворити_на_ллвмір(Модуль* модуль,
                                      природне* вихід_розміру,
                                      п8** вихід_даних) {
  llvm::SmallVector<char, 0> buffer;
  llvm::raw_svector_ostream os(buffer);

  модуль->print(os, nullptr);

  if (buffer.empty()) {
    *вихід_розміру = 0;
    *вихід_даних = nullptr;

    return false;
  } else {
    *вихід_розміру = buffer.size();
    *вихід_даних = (п8*)malloc(buffer.size());
    memcpy(*вихід_даних, buffer.data(), buffer.size());

    return true;
  }
}

логічне __ЛЛВМ__перетворити_на_ллвмо(Модуль* модуль,
                                     природне* вихід_розміру,
                                     п8** вихід_даних) {
  auto targetTriple = модуль->getTargetTriple();

  std::string Error;
  auto Target = llvm::TargetRegistry::lookupTarget(targetTriple, Error);
  if (!Error.empty()) {
    std::cout << Error << std::endl;
    return false;
  }

  auto CPU = "generic";
  auto Features = "";

  llvm::TargetOptions opt;

  auto llvmTargetMachine = Target->createTargetMachine(
      targetTriple, CPU, Features, opt, llvm::Reloc::PIC_);

  llvm::SmallVector<char, 0> buffer;
  llvm::raw_svector_ostream dest(buffer);

  llvm::legacy::PassManager pass;
  auto FileType = llvm::CodeGenFileType::ObjectFile;

  if (llvmTargetMachine->addPassesToEmitFile(pass, dest, nullptr, FileType)) {
    llvm::errs() << "TheTargetMachine can't emit a file of this type";
    return false;
  }

  pass.run(*модуль);

  if (buffer.empty()) {
    *вихід_даних = nullptr;
    *вихід_розміру = 0;
    return true;
  } else {
    *вихід_даних = (п8*)malloc(buffer.size());
    memcpy(*вихід_даних, buffer.data(), buffer.size());
    *вихід_розміру = buffer.size();
    return true;
  }
}
}